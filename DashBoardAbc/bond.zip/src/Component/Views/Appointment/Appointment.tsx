import React from 'react'

const Appointment=()=>{
    return (
        <div>
            doctors
        </div>
    )
}

export default Appointment;