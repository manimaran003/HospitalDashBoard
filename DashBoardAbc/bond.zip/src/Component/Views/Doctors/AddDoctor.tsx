import React from 'react'

const AddDoctor=()=>{
    return (
        <div>
            add doctor
        </div>
    )
}

export default AddDoctor;