import React from 'react'

const DeleteDoctors=()=>{
    return (
        <div>
           deleet doctors
        </div>
    )
}

export default DeleteDoctors;