import React from 'react'

const EditDoctor=()=>{
    return (
        <div>
            Edit doctor
        </div>
    )
}

export default EditDoctor ;