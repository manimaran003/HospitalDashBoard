import React from 'react'

const Patients=()=>{
    return (
        <div>
            Patients
        </div>
    )
}

export default Patients;