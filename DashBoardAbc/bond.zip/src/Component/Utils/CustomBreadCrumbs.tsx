import React from 'react'

const CustomBreadCrumbs=()=>{
    return (
        <div>
            custom bred crumb
        </div>
    )
}

export default CustomBreadCrumbs;